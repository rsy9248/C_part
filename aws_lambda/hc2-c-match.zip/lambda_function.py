"""
AWS Lambda: hc2-c-match  (핸들러: lambda_function.lambda_handler)

입력  {"category": "chest pain", "grade": 2, "lat": 37.87, "lng": 127.73}
출력  FastAPI emergency_match의 원래 응답 형식(status / success / detected_disease_code /
      radius_matched_km / results ...)에 best_hospital(가장 가까운 1곳)을 더한 JSON

- Lambda는 로컬 SQLite가 유지되지 않으므로, 호출할 때 공공 API에서 병원 데이터를 받아 매칭합니다.
  (같은 컨테이너가 재사용되는 동안은 메모리 캐시를 써서 공공 API 호출을 줄입니다.)
- 외부 패키지 없이 표준 라이브러리만 사용합니다. (requests 등 설치 불필요)
- 질환 코드 매핑은 같은 zip 안의 rules/disease_rules.json을 사용합니다.

환경변수
  PUBLIC_API_KEY   (필수) 공공데이터포털 일반 인증키(Decoding)
  ER_REGION        (선택) 특정 시도만 수집 (예: 강원특별자치도). 비우면 전체
  BEDS_TTL_SEC     (선택) 병상/수용정보 캐시 유지 시간, 기본 300
  MAX_RESULTS      (선택) 응답에 담을 최대 병원 수, 기본 20
"""
import base64
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from math import atan2, cos, radians, sin, sqrt

from rules.disease_rules import UNKNOWN_CODE, classify_category, disease_api_keys

# ----------------------------------------------------------------------
# 설정
# ----------------------------------------------------------------------
SERVICE_KEY = os.environ.get("PUBLIC_API_KEY", "")
BASE_URL = "https://apis.data.go.kr/B552657/ErmctInfoInqireService"

OP_BEDS = "getEmrrmRltmUsefulSckbdInfoInqire"      # 응급실 실시간 가용병상정보
OP_SEVERE = "getSrsillDissAceptncPosblInfoInqire"  # 중증질환자 수용가능정보
OP_LIST = "getEgytListInfoInqire"                  # 응급의료기관 목록정보 (주소/전화/좌표)

REGION = os.environ.get("ER_REGION", "")
REGION_PARAM = {OP_BEDS: "STAGE1", OP_SEVERE: "STAGE1", OP_LIST: "Q0"}

ROWS_PER_PAGE = int(os.environ.get("ROWS_PER_PAGE", "100"))
MAX_PAGES = int(os.environ.get("MAX_PAGES", "10"))
TIMEOUT = int(os.environ.get("API_TIMEOUT_SEC", "8"))
BEDS_TTL_SEC = int(os.environ.get("BEDS_TTL_SEC", "300"))      # 병상/수용정보: 자주 바뀜
LOCATION_TTL_SEC = 24 * 60 * 60                                 # 좌표/주소: 거의 안 바뀜
MAX_RESULTS = int(os.environ.get("MAX_RESULTS", "20"))
MAX_CHECKED = 30   # 후보가 없을 때 상황실 전달용으로 담을 병원 수

RADIUS_STAGES_KM = [5, 15, 30, 50]


class DataUnavailable(Exception):
    """공공 API에서 병원 데이터를 가져오지 못한 경우."""


# ----------------------------------------------------------------------
# 공공 API 호출 / 파싱 (표준 라이브러리만 사용)
# ----------------------------------------------------------------------
def _parse_response(text):
    """XML 또는 JSON 응답을 (items, totalCount)로 변환. 에러 응답이면 DataUnavailable."""
    text = text.strip()
    try:
        if text.startswith("<"):
            root = ET.fromstring(text)
            code = root.findtext(".//resultCode")
            if code is None:
                code = root.findtext(".//returnReasonCode")
            if code not in ("00", "0"):
                msg = root.findtext(".//resultMsg") or root.findtext(".//returnAuthMsg")
                raise DataUnavailable(f"API 에러 코드={code}, 메시지={msg}")
            items = [
                {child.tag: (child.text or "").strip() for child in item}
                for item in root.findall(".//item")
            ]
            total = int(root.findtext(".//totalCount") or len(items))
            return items, total

        data = json.loads(text)
    except (ET.ParseError, ValueError) as e:
        raise DataUnavailable(f"응답 파싱 실패: {e}")

    response = data.get("response", {})
    header = response.get("header", {})
    code = str(header.get("resultCode", ""))
    if code not in ("00", "0"):
        raise DataUnavailable(f"API 에러 코드={code}, 메시지={header.get('resultMsg')}")
    body = response.get("body", {})
    raw = body.get("items", {})
    raw = raw.get("item", []) if isinstance(raw, dict) else []
    items = [raw] if isinstance(raw, dict) else raw
    return items, int(body.get("totalCount", len(items)))


def _fetch_operation(operation):
    """한 오퍼레이션의 모든 페이지를 받아 item 리스트로 반환. 실패하면 DataUnavailable."""
    collected = []
    for page in range(1, MAX_PAGES + 1):
        params = {
            "serviceKey": SERVICE_KEY,
            "pageNo": str(page),
            "numOfRows": str(ROWS_PER_PAGE),
        }
        if REGION and operation in REGION_PARAM:
            params[REGION_PARAM[operation]] = REGION

        url = f"{BASE_URL}/{operation}?{urllib.parse.urlencode(params)}"
        try:
            with urllib.request.urlopen(url, timeout=TIMEOUT) as resp:
                text = resp.read().decode("utf-8")
        except (urllib.error.URLError, OSError) as e:   # HTTPError, 타임아웃 포함
            raise DataUnavailable(f"{operation} 통신 에러: {e}")

        items, total = _parse_response(text)
        if not items:
            break
        collected.extend(items)
        if len(collected) >= total:
            break
    return collected


# 같은 Lambda 컨테이너가 재사용되는 동안 유지되는 메모리 캐시: {이름: (받은 시각, 데이터)}
_cache = {}


def _get_cached(name, operation, ttl):
    """캐시가 신선하면 재사용, 아니면 새로 받기. 새로 받기 실패 시 오래된 캐시라도 사용."""
    now = time.time()
    entry = _cache.get(name)
    if entry and now - entry[0] < ttl:
        return entry[1], False, entry[0]
    try:
        data = _fetch_operation(operation)
        if not data:
            raise DataUnavailable(f"{operation} 결과가 비어 있습니다.")
        _cache[name] = (now, data)
        return data, False, now
    except DataUnavailable as e:
        if entry:
            print(f"[hc2-c-match] {name} 갱신 실패, 이전 캐시 사용: {e}")
            return entry[1], True, entry[0]
        raise


# ----------------------------------------------------------------------
# 값 변환 / 병원 데이터 병합
# ----------------------------------------------------------------------
def _get(item, *keys, default=""):
    """대소문자 구분 없이 여러 후보 키 중 먼저 있는 값을 반환."""
    lowered = {k.lower(): v for k, v in item.items()}
    for key in keys:
        value = lowered.get(key.lower())
        if value not in (None, ""):
            return value
    return default


def _to_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _to_int(value):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def _any_yes(item, keys):
    return "Y" if any(str(_get(item, k)).strip().upper() == "Y" for k in keys) else "N"


def _index_by_hpid(items):
    return {_get(i, "hpid"): i for i in (items or []) if _get(i, "hpid")}


def load_hospitals():
    """공공 API 3종을 병렬로 받아 병원 리스트로 병합. (hospitals, {"fetched_at", "stale"}) 반환."""
    if not SERVICE_KEY:
        raise DataUnavailable("PUBLIC_API_KEY 환경변수가 설정되지 않았습니다.")

    sources = {
        "beds": (OP_BEDS, BEDS_TTL_SEC),
        "severe": (OP_SEVERE, BEDS_TTL_SEC),
        "loc": (OP_LIST, LOCATION_TTL_SEC),
    }
    with ThreadPoolExecutor(max_workers=len(sources)) as ex:
        futures = {name: ex.submit(_get_cached, name, op, ttl) for name, (op, ttl) in sources.items()}
        results = {name: f.result() for name, f in futures.items()}   # 실패 시 DataUnavailable 전파

    beds, severe, loc = (results[n][0] for n in ("beds", "severe", "loc"))
    meta = {
        "fetched_at": int(min(results["beds"][2], results["severe"][2])),
        "stale": any(results[n][1] for n in results),
    }

    api_keys = disease_api_keys()
    severe_by_id = _index_by_hpid(severe)
    loc_by_id = _index_by_hpid(loc)

    hospitals = []
    for item in beds:
        hpid = _get(item, "hpid")
        if not hpid:
            continue
        sev = severe_by_id.get(hpid, {})
        place = loc_by_id.get(hpid, {})
        hospitals.append({
            "hospital_id": hpid,
            "hospital_name": _get(item, "dutyName") or _get(place, "dutyName", default="알 수 없는 병원"),
            "lat": _to_float(_get(place, "wgs84Lat", "latitude", "lat")),
            "lng": _to_float(_get(place, "wgs84Lon", "longitude", "lon", "lng")),
            "emergency_beds": _to_int(_get(item, "hvec")),
            "disease_status": {code: _any_yes(sev, keys) for code, keys in api_keys.items()},
            "tel_er": _get(item, "dutyTel3") or _get(place, "dutyTel3"),
            "address": _get(place, "dutyAddr"),
            "updated_at": _get(item, "hvidate"),
        })
    return hospitals, meta


# ----------------------------------------------------------------------
# 매칭 (FastAPI main.py와 같은 규칙)
# ----------------------------------------------------------------------
def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    return R * 2 * atan2(sqrt(a), sqrt(1 - a))


def search_in_radius(hospitals, lat, lng, radius, disease_code):
    """반경 내 병원을 검사해 (수용 가능 목록, 검사한 전체 목록)을 거리순으로 반환."""
    matched, checked = [], []
    for h in hospitals:
        if h["lat"] == 0.0 or h["lng"] == 0.0:
            continue
        distance = haversine_km(lat, lng, h["lat"], h["lng"])
        if distance > radius:
            continue

        has_beds = h["emergency_beds"] > 0
        if disease_code == UNKNOWN_CODE:
            can_accept = True
        else:
            can_accept = h["disease_status"].get(disease_code, "N") == "Y"

        info = {
            "hospital_id": h["hospital_id"],
            "hospital_name": h["hospital_name"],
            "distance_km": round(distance, 2),
            "emergency_beds": h["emergency_beds"],
            "can_accept": can_accept,
            "lat": h["lat"],
            "lng": h["lng"],
            "tel_er": h["tel_er"],
            "address": h["address"],
            "updated_at": h["updated_at"],
        }
        checked.append(info)
        if has_beds and can_accept:
            matched.append(info)

    matched.sort(key=lambda x: x["distance_km"])
    checked.sort(key=lambda x: x["distance_km"])
    return matched, checked


def _validate(payload):
    if not isinstance(payload, dict):
        raise ValueError("요청은 JSON 객체여야 합니다.")
    category = payload.get("category")
    if not isinstance(category, str) or not category.strip():
        raise ValueError("category(주증상 범주)가 필요합니다.")
    try:
        grade = int(payload.get("grade"))
    except (TypeError, ValueError):
        raise ValueError("grade는 1~5 정수여야 합니다.")
    if not 1 <= grade <= 5:
        raise ValueError("grade는 1~5 정수여야 합니다.")
    try:
        lat, lng = float(payload.get("lat")), float(payload.get("lng"))
    except (TypeError, ValueError):
        raise ValueError("lat, lng는 숫자여야 합니다.")
    if not (-90 <= lat <= 90 and -180 <= lng <= 180):
        raise ValueError("lat, lng 범위가 올바르지 않습니다.")
    return category.strip(), grade, lat, lng


def match(payload):
    category, grade, lat, lng = _validate(payload)
    disease = classify_category(category)
    code = disease["code"]
    hospitals, meta = load_hospitals()

    base = {
        "detected_disease_code": code,
        "detected_disease_name": disease["name"],
        "category": category,
        "category_known": disease["category_known"],   # False면 cc_category 목록에 없는 이름 (오타/신규 범주)
        "grade": grade,
        "data_fetched_at": meta["fetched_at"],   # 병상 데이터를 받은 시각 (epoch 초)
        "data_stale": meta["stale"],             # True면 공공 API 갱신 실패로 이전 데이터 사용 중
    }

    checked = []
    for radius in RADIUS_STAGES_KM:
        matched, checked = search_in_radius(hospitals, lat, lng, radius, code)
        if matched:
            return {
                "status": "OK",
                "success": True,
                **base,
                "radius_matched_km": radius,
                "best_hospital": matched[0],         # 가장 가까운 1곳
                "results": matched[:MAX_RESULTS],    # 거리순 후보 (원래 emergency_match 형식)
            }

    return {
        "status": "NO_AVAILABLE_HOSPITAL",
        "success": False,
        **base,
        "warning": "수용 가능 병원 없음. 구급상황관리센터 전달용 요약 정보를 생성합니다.",
        "checked_count": len(checked),
        "checked_hospitals": checked[:MAX_CHECKED],
        "action_required": "상황실에 환자 상태 및 거절 사유를 일괄 전달하고 전원/안정화 병원 조율 요청",
    }


# ----------------------------------------------------------------------
# Lambda 진입점
# ----------------------------------------------------------------------
def _is_http_event(event):
    """API Gateway/Function URL 이벤트는 body가 JSON 문자열, 직접 invoke는 event가 곧 입력."""
    return isinstance(event, dict) and isinstance(event.get("body"), str)


def _parse_event(event):
    if not _is_http_event(event):
        return event
    body = event["body"]
    if event.get("isBase64Encoded"):
        body = base64.b64decode(body).decode("utf-8")
    return json.loads(body or "{}")


def _respond(is_http, result, status_code):
    if is_http:
        return {
            "statusCode": status_code,
            "headers": {"Content-Type": "application/json; charset=utf-8"},
            "body": json.dumps(result, ensure_ascii=False),
        }
    return result


def lambda_handler(event, context=None):
    is_http = _is_http_event(event)   # 파싱 실패 시에도 응답 형식(HTTP 여부)을 먼저 정해 둠
    try:
        payload = _parse_event(event)
        result = match(payload)
        status_code = 200
    except ValueError as e:                  # 입력 오류 (JSON 파싱 오류 포함)
        result = {"status": "ERROR", "success": False, "error": str(e)}
        status_code = 400
    except DataUnavailable as e:             # 공공 API 데이터를 못 가져옴
        print(f"[hc2-c-match] 데이터 오류: {e}")
        result = {"status": "ERROR", "success": False, "error": f"병원 데이터를 가져오지 못했습니다: {e}"}
        status_code = 503

    print(f"[hc2-c-match] status={result.get('status')} category={result.get('category')} "
          f"grade={result.get('grade')} radius={result.get('radius_matched_km')}")
    return _respond(is_http, result, status_code)
